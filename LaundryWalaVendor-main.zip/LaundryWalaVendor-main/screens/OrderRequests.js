import React from "react";
import {
  StyleSheet,
  View,
  SafeAreaView,
  Platform,
  StatusBar,
  TouchableOpacity,
  ScrollView,
} from "react-native";
import { Text } from "galio-framework";

class RecentOrders extends React.Component {
  render() {
    return (
      <SafeAreaView style={styles.container}>
        <ScrollView style={styles.scroll}>
          {/*orders count within specific time*/}
          <Text style={styles.blueText}>8 Requests Found</Text>

          {/*orders block starting*/}
          <View style={styles.orderBlocks}>
            <View style={styles.innerBlock}>
              <Text style={styles.customerName}>Customer Name</Text>
              <TouchableOpacity style={styles.orderAcceptBtn}>
                <Text style={styles.orderAcceptTxt}>Accept</Text>
              </TouchableOpacity>
            </View>
            <View style={styles.innerBlock}>
              <Text p muted>
                PKR: 200
              </Text>
              <TouchableOpacity
                style={styles.orderDetailBtn}
                onPress={() => this.props.navigation.navigate("OrderDetail")}
              >
                <Text style={styles.blueText}>Order Detail</Text>
              </TouchableOpacity>
            </View>
            <Text p muted style={styles.completedTime}>
              10 mins ago
            </Text>
          </View>
          {/*orders block ending*/}

          {/*orders block starting*/}
          <View style={styles.orderBlocks}>
            <View style={styles.innerBlock}>
              <Text style={styles.customerName}>Customer Name</Text>
              <TouchableOpacity style={styles.orderAcceptBtn}>
                <Text style={styles.orderAcceptTxt}>Accept</Text>
              </TouchableOpacity>
            </View>
            <View style={styles.innerBlock}>
              <Text p muted>
                PKR: 200
              </Text>
              <TouchableOpacity
                style={styles.orderDetailBtn}
                onPress={() => this.props.navigation.navigate("OrderDetail")}
              >
                <Text style={styles.blueText}>Order Detail</Text>
              </TouchableOpacity>
            </View>
            <Text p muted style={styles.completedTime}>
              10 mins ago
            </Text>
          </View>
          {/*orders block ending*/}

          {/*orders block starting*/}
          <View style={styles.orderBlocks}>
            <View style={styles.innerBlock}>
              <Text style={styles.customerName}>Customer Name</Text>
              <TouchableOpacity style={styles.orderAcceptBtn}>
                <Text style={styles.orderAcceptTxt}>Accept</Text>
              </TouchableOpacity>
            </View>
            <View style={styles.innerBlock}>
              <Text p muted>
                PKR: 200
              </Text>
              <TouchableOpacity
                style={styles.orderDetailBtn}
                onPress={() => this.props.navigation.navigate("OrderDetail")}
              >
                <Text style={styles.blueText}>Order Detail</Text>
              </TouchableOpacity>
            </View>
            <Text p muted style={styles.completedTime}>
              10 mins ago
            </Text>
          </View>
          {/*orders block ending*/}

          {/*orders block starting*/}
          <View style={styles.orderBlocks}>
            <View style={styles.innerBlock}>
              <Text style={styles.customerName}>Customer Name</Text>
              <TouchableOpacity style={styles.orderAcceptBtn}>
                <Text style={styles.orderAcceptTxt}>Accept</Text>
              </TouchableOpacity>
            </View>
            <View style={styles.innerBlock}>
              <Text p muted>
                PKR: 200
              </Text>
              <TouchableOpacity
                style={styles.orderDetailBtn}
                onPress={() => this.props.navigation.navigate("OrderDetail")}
              >
                <Text style={styles.blueText}>Order Detail</Text>
              </TouchableOpacity>
            </View>
            <Text p muted style={styles.completedTime}>
              10 mins ago
            </Text>
          </View>
          {/*orders block ending*/}

          {/*orders block starting*/}
          <View style={styles.orderBlocks}>
            <View style={styles.innerBlock}>
              <Text style={styles.customerName}>Customer Name</Text>
              <TouchableOpacity style={styles.orderAcceptBtn}>
                <Text style={styles.orderAcceptTxt}>Accept</Text>
              </TouchableOpacity>
            </View>
            <View style={styles.innerBlock}>
              <Text p muted>
                PKR: 200
              </Text>
              <TouchableOpacity
                style={styles.orderDetailBtn}
                onPress={() => this.props.navigation.navigate("OrderDetail")}
              >
                <Text style={styles.blueText}>Order Detail</Text>
              </TouchableOpacity>
            </View>
            <Text p muted style={styles.completedTime}>
              10 mins ago
            </Text>
          </View>
          {/*orders block ending*/}

          {/*orders block starting*/}
          <View style={styles.orderBlocks}>
            <View style={styles.innerBlock}>
              <Text style={styles.customerName}>Customer Name</Text>
              <TouchableOpacity style={styles.orderAcceptBtn}>
                <Text style={styles.orderAcceptTxt}>Accept</Text>
              </TouchableOpacity>
            </View>
            <View style={styles.innerBlock}>
              <Text p muted>
                PKR: 200
              </Text>
              <TouchableOpacity
                style={styles.orderDetailBtn}
                onPress={() => this.props.navigation.navigate("OrderDetail")}
              >
                <Text style={styles.blueText}>Order Detail</Text>
              </TouchableOpacity>
            </View>
            <Text p muted style={styles.completedTime}>
              10 mins ago
            </Text>
          </View>
          {/*orders block ending*/}

          {/*orders block starting*/}
          <View style={styles.orderBlocks}>
            <View style={styles.innerBlock}>
              <Text style={styles.customerName}>Customer Name</Text>
              <TouchableOpacity style={styles.orderAcceptBtn}>
                <Text style={styles.orderAcceptTxt}>Accept</Text>
              </TouchableOpacity>
            </View>
            <View style={styles.innerBlock}>
              <Text p muted>
                PKR: 200
              </Text>
              <TouchableOpacity
                style={styles.orderDetailBtn}
                onPress={() => this.props.navigation.navigate("OrderDetail")}
              >
                <Text style={styles.blueText}>Order Detail</Text>
              </TouchableOpacity>
            </View>
            <Text p muted style={styles.completedTime}>
              10 mins ago
            </Text>
          </View>
          {/*orders block ending*/}

          {/*orders block starting*/}
          <View style={styles.orderBlocks}>
            <View style={styles.innerBlock}>
              <Text style={styles.customerName}>Customer Name</Text>
              <TouchableOpacity style={styles.orderAcceptBtn}>
                <Text style={styles.orderAcceptTxt}>Accept</Text>
              </TouchableOpacity>
            </View>
            <View style={styles.innerBlock}>
              <Text p muted>
                PKR: 200
              </Text>
              <TouchableOpacity
                style={styles.orderDetailBtn}
                onPress={() => this.props.navigation.navigate("OrderDetail")}
              >
                <Text style={styles.blueText}>Order Detail</Text>
              </TouchableOpacity>
            </View>
            <Text p muted style={styles.completedTime}>
              10 mins ago
            </Text>
          </View>
          {/*orders block ending*/}
        </ScrollView>
      </SafeAreaView>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    paddingTop: Platform.OS === "android" ? StatusBar.currentHeight : 0,
    paddingLeft: 10,
    paddingRight: 10,
  },
  scroll: {
    marginTop: -20,
  },
  completedTime: {
    fontSize: 10,
  },
  orderStatus: {
    marginRight: 8,
  },
  orderBlocks: {
    marginBottom: 10,
    marginLeft: 5,
    marginRight: 5,
    marginTop: 5,
    backgroundColor: "white",
    padding: 5,
    borderRadius: 10,
    shadowColor: "#000",
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,
    elevation: 5,
  },
  customerName: {
    fontSize: 20,
    color: "#084E96",
  },
  blueText: {
    color: "#084E96",
  },
  orderDetailBtn: {
    borderWidth: 0.5,
    borderColor: "#084E96",
    padding: 5,
    borderRadius: 10,
  },
  innerBlock: {
    flex: 1,
    flexDirection: "row",
    justifyContent: "space-between",
    paddingBottom: 10,
  },
  orderAcceptBtn: {
    borderWidth: 0.5,
    borderColor: "#660014",
    padding: 5,
    borderRadius: 10,
    backgroundColor: "#ffa600",
    width: "26%",
    alignItems: "center",
  },
  orderAcceptTxt: {
    color: "#660014",
  },
});

export default RecentOrders;
