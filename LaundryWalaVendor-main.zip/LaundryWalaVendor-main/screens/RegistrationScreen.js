import React from "react";
import {
  StyleSheet,
  Text,
  View,
  SafeAreaView,
  Platform,
  StatusBar,
  Button,
  TextInput,
  linear,
  TouchableOpacity,
  Image,
} from "react-native";
import { LinearGradient } from "expo-linear-gradient";

class RegistrationScreen extends React.Component {
  render() {
    return (
      <LinearGradient colors={["#ffffff", "#00EDFF"]} style={{ flex: 1 }}>
        <SafeAreaView style={styles.container}>
          <Text
            style={{
              fontSize: 25,
              color: "orange",
              marginTop: 10,
              marginBottom: 10,
            }}
          >
            {" "}
            REGISTRATION (اندراج)
          </Text>
          <TextInput style={styles.input} placeholder="FULL NAME (پورا نام)" />
          <TextInput
            style={styles.input}
            placeholder="FATHERS NAME (باپ کا نام)"
          />
          <TextInput
            style={styles.input}
            placeholder="MOBILE NUMBER (موبائل نمبر)"
          />
          <TextInput
            style={styles.input}
            placeholder="CNIC NO (شناختی کارڈ نمبر)"
          />
          <TextInput
            style={styles.input}
            placeholder="SHOP ADDRESS (دکان کا پتہ)"
          />
          <TextInput
            style={styles.input}
            placeholder="SHOP AREA (دکان کا علاقہ)"
          />
          <TextInput style={styles.input} placeholder="CITY (شہر)" />

          <View style={{ paddingTop: 20 }}>
            <Button
              title="SUBMIT INFORMATION--(معلومات جمع کروائیں)"
              onPress={() => this.props.navigation.navigate("Map")}
            />
          </View>
        </SafeAreaView>
      </LinearGradient>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    paddingTop: Platform.OS === "android" ? StatusBar.currentHeight : 0,
    alignItems: "center",
    justifyContent: "center",
  },
  input: {
    width: "80%",
    backgroundColor: "#ffffff",
    marginBottom: 10,
    borderRadius: 10,
    padding: 10,
    justifyContent: "center",
  },
});

export default RegistrationScreen;
