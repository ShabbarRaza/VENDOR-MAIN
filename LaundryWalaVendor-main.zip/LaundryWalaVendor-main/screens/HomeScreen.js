import * as React from "react";
import { Text, View } from "react-native";
import { NavigationContainer } from "@react-navigation/native";
import { createMaterialTopTabNavigator } from "@react-navigation/material-top-tabs";
import RecentOrders from "./RecentOrders";
import OrderInProgress from "./OrderInProgress";
import OrderRequests from "./OrderRequests";

const Tab = createMaterialTopTabNavigator();

export default function MyTabs() {
  return (
    <Tab.Navigator
      initialRouteName="Home"
      tabBarOptions={{
        activeTintColor: "blue",
        labelStyle: { fontSize: 12 },
        style: { backgroundColor: "#00EDFF" },
      }}
    >
      <Tab.Screen name="Recent Orders" component={RecentOrders} />
      <Tab.Screen name="Orders In Progress" component={OrderInProgress} />
      <Tab.Screen name="Order Requests" component={OrderRequests} />
    </Tab.Navigator>
  );
}
