import React from "react";
import {
  StyleSheet,
  Text,
  View,
  SafeAreaView,
  Platform,
  StatusBar,
  Button,
  TextInput,
  linear,
  TouchableOpacity,
  Image,
} from "react-native";
import { LinearGradient } from "expo-linear-gradient";

class LoginScreen extends React.Component {
  render() {
    return (
      <LinearGradient colors={["#ffffff", "#00EDFF"]} style={{ flex: 1 }}>
        <SafeAreaView style={styles.container}>
          <Text style={styles.headingText}>Login</Text>
          <TextInput
            style={styles.textInput}
            placeholder="Mobile Number (موبائل نمبر)"
          />
          <TextInput
            style={styles.textInput}
            placeholder="Password"
            secureTextEntry
          />
          <Button
            title="Login now"
            onPress={() => this.props.navigation.navigate("Home")}
          />
        </SafeAreaView>
      </LinearGradient>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    paddingTop: Platform.OS === "android" ? StatusBar.currentHeight : 0,
    alignItems: "center",
    justifyContent: "center",
  },
  headingText: {
    fontSize: 25,
    color: "orange",
    marginTop: 10,
    marginBottom: 10,
  },
  textInput: {
    width: "80%",
    backgroundColor: "#fff",
    marginBottom: 10,
    borderRadius: 10,
    padding: 10,
    justifyContent: "center",
  },
});

export default LoginScreen;
